﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Results;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using HiveServer.Models;
using HiveServer.Models.FarmData;


namespace HiveServer.Controllers
{
    [Route("Farms/{farmId}/Staff")]
    [Authorize]
    public class StaffController : ApiController
    {

        private ApplicationDbContext db = new ApplicationDbContext();

        public ApplicationUserManager UserManager
        {
            get
            {
                return Request.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
        }
        
       
      //  /// <summary>
      //  /// Creates connection between a given user and the 
      //  /// </summary>
      //  /// <param name="model"></param>
      //  /// <returns></returns>
      //  public async Task<IHttpActionResult> Post([FromBody]BondBindingModel model)
      //  {
      //      if (!ModelState.IsValid)
      //      {
      //          return BadRequest(ModelState);
      //      }
      //      else if (model == null)
      //      {
      //          return BadRequest("You sent no data");
      //      }
      //      else
      //      {
      //          var userID = User.Identity.GetUserId();
      //          var user = db.Users.Find(userID);

      //         // user.ContactBook.Exists(p => p.Friend2Id == model|| p => p.Friend1Id)



      //          //var newBond = new Bond(newFarm, BondType.Owner);
            
      //          //user.Bound.Add(newBond);
      //          //await db.SaveChangesAsync();

      //          //return Ok();
                
      //      }
      //  }

      ///// <summary>
      ///// Updates an existing farm. It must belong to the user. 
      ///// </summary>
      ///// <param name="farmId"></param>
      ///// <param name="model"></param>
      ///// <returns></returns>
      //  [Route("Farms/{farmId}")]
      //  public async Task<IHttpActionResult> Put([FromUri]long farmId, [FromBody]FarmBindingModel model)
      //  {
      //      if (!ModelState.IsValid)
      //      {
      //          return BadRequest(ModelState);
      //      }
      //      else if (model == null)
      //      {
      //          return BadRequest("You sent no data");
      //      }
      //      else
      //      {
      //          var userId = User.Identity.GetUserId();
      //          var user = db.Users.Find(userId);

      //          List<Bond> bindings = await db.Bindings.Where(b => b.FarmID == farmId &&!  b.Farm.Disabled )
      //              .ToListAsync();

      //          if (bindings.Count == 0)
      //          {
      //              return NotFound(); //this farm does not exist
      //          }
      //          else
      //          {
      //              Bond bond = bindings.FirstOrDefault(p => p.PersonID == userId);
      //              if (bond == null)
      //              {
      //                  return Unauthorized(); //user is not attached to this farm
      //              }
      //              else if (bond.Type != BondType.Manager && bond.Type != BondType.Owner)
      //              {
      //                  return Unauthorized(); //user is not authorised to make changes to this farm
      //              }
      //              else
      //              {//user is authorised, make nessesary changes! 
      //                  var farm = bond.Farm;
      //                  if (!string.IsNullOrWhiteSpace(model.Name))
      //                  { farm.Name = model.Name;}
      //                  if (!string.IsNullOrWhiteSpace(model.Description))
      //                  { farm.Description = model.Description;}

      //                  await db.SaveChangesAsync();
      //                  return Ok();
      //              }
      //          }

      //      }
      //  }


      //  /// <summary>
      //  /// Removes the required farm completely 
      //  /// </summary>
      //  /// <param name="farmId"></param>
      //  /// <returns></returns>
      //  [Route("Farms/{farmId}")]
      //  public async Task<IHttpActionResult> Delete([FromUri]long farmId)
      //  {
      //      var userId = User.Identity.GetUserId();
      //      var user = db.Users.Find(userId);

      //      List<Bond> bindings = await db.Bindings.Where(b => b.FarmID == farmId && ! b.Farm.Disabled)
      //          .ToListAsync();

      //      if (bindings.Count == 0)
      //      {
      //          return NotFound(); //this farm does not exist
      //      }
      //      else
      //      {
      //          Bond bond = bindings.FirstOrDefault(p => p.PersonID == userId);
      //          if (bond == null)
      //          {
      //              return Unauthorized(); //user is not attached to this farm
      //          }
      //          else if (bond.Type != BondType.Owner)
      //          {
      //              return Unauthorized(); //user is not authorised to delete this farm

      //          }
      //          else
      //          {
      //              //Cut this person's connection with the farm
      //              if (bond.Farm.Fields.Exists(p => ! p.Disabled) && bond.Farm.Fields.Count > 0)
      //              {
      //                  return BadRequest("You cannot delete the farm as long as there are still fields attached to it"); 
      //              }
      //              else
      //              {
      //                  bond.Farm.Disabled = true; 
      //                  await db.SaveChangesAsync();
      //                  return Ok();
      //              }

      //          }
      //      }
      //  }
        
        

    }
}
