﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Results;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using HiveServer.Models;


namespace HiveServer.Controllers
{
    [Authorize]public class FriendsController : ApiController
    {

        private ApplicationDbContext db = new ApplicationDbContext();

        /// <summary> Gets a list of contacts that this user knows </summary>
        /// <returns>List of Contacts that this user has</returns>

        //public async Task<List<PersonViewModel>> Get()
        //{
        //    var userId = User.Identity.GetUserId();

        //    //Pre-load all the 
        //    var friendsNet = await RetrieveFriends(db, userId);

        //    List<PersonViewModel> responce = new List<PersonViewModel>();

        //    foreach (var friendship in friendsNet)
        //    {
        //        responce.Add(friendship.ViewModel(userId));
        //    }

        //    return responce; 
        //}

        /////// <summary>
        /////// Creates a new contact with a user of specified GUID. 
        /////// </summary>
        /////// <param name="userID"></param>
        /////// <returns></returns>
        ////[ResponseType(typeof (FriendshipChangeViewModel))]
        ////[Route("ContactBook")]
        ////public async Task<IHttpActionResult> Put([FromUri] Guid userID)
        ////{
            
        ////}



        /////// <summary>
        /////// Adds Contacts to the user's contactBook. Can accept a signle user or an entire array, which must consist of user's GUID and, optionally, nickname
        /////// If the contacts already exist, it will Update nicknames
        /////// </summary>
        /////// <param name="models"></param>
        /////// <returns>Returns an updated list of Contacts taht his user has</returns>
        ////[ResponseType(typeof(FriendshipChangeViewModel))]
        ////[Route("ContactBook")]
        ////public async Task<IHttpActionResult> Put([FromBody]List<RecordBindingModel> models)
        ////{
        ////    if (!ModelState.IsValid)
        ////    {
        ////        return BadRequest(ModelState);
        ////    }
        ////    else if (models.Count > 1000)
        ////    {
        ////        return BadRequest("That many users? Fuck off");
        ////    }
        ////    else if (models.Count < 1)
        ////    {
        ////        return BadRequest("No data");
        ////    }
        ////    else
        ////    {
        ////        var userId = User.Identity.GetUserId();
 
        ////        var friendsNet = await  db.ContactBook.Where(p => p.Friend1Id == userId || p.Friend2Id == userId )
        ////        .Include(u => u.Friend1).Include(u => u.Friend2).ToListAsync();

        ////        List<Friendship> Forward = friendsNet.Where(p => p.Friend1Id == userId).ToList();
        ////        List<Friendship> Backwards = friendsNet.Where(p => p.Friend2Id == userId).ToList();
               

                
        ////        FriendshipChangeViewModel responce = new FriendshipChangeViewModel();

        ////        //iterate for each record recieved
        ////        foreach (var inRecord in models)
        ////        {
        ////            //Reference to a Friend in the user's contact book, will be null if the record does not exist yet
        ////            var friendship = friendsNet.FirstOrDefault(p => p.Friend1Id == inRecord.ContactID.ToString() || p.Friend2Id == inRecord.ContactID.ToString());
                    
        ////            bool alreadyExists = friendship != null;
                    


        ////            if (alreadyExists)
        ////            {
        ////                //forward is true if the first userID is the user currently making the request
        ////                bool forward = friendship.Friend1Id == userId;

        ////                if (inRecord.State == DBRelationshipState.Blockedu2 || inRecord.State == DBRelationshipState.Blockedu1)
        ////                { //if the user is trying to make an existing relationship blocked, they need to be friends or pending responce
        ////                    if (friendship.State == DBRelationshipState.Pending ||
        ////                        friendship.State == DBRelationshipState.Friends)
        ////                    {
        ////                        if (forward)
        ////                        {
        ////                            friendship.State = DBRelationshipState.Blockedu2;
        ////                            responce.Altered++;
        ////                        }
        ////                        else
        ////                        {
        ////                            friendship.State = DBRelationshipState.Blockedu1;
        ////                            responce.Altered++;
        ////                        }
        ////                    }
        ////                    else
        ////                    {
        ////                        responce.Invalid++; 
        ////                    }
        ////                }
        ////                if (inRecord.State == DBRelationshipState.Friends)
        ////                {
        ////                    if (friendship.State == DBRelationshipState.Pending)
        ////                    {
        ////                        if (forward)
        ////                        { //if request is pending, only the second user can accept it!
        ////                            responce.Invalid++;
        ////                        }
        ////                        else
        ////                        {
        ////                            friendship.State = DBRelationshipState.Friends;
        ////                            responce.Altered++;
        ////                        }
        ////                    }
        ////                    else
        ////                    {
        ////                        responce.Invalid++;
        ////                    }
                            
        ////                }
        ////                if (inRecord.State == DBRelationshipState.Pending || //you cannot edit an existing relationship and make it pending or NA
        ////                    inRecord.State == DBRelationshipState.NotApplicable)
        ////                {
        ////                    responce.Invalid++;
        ////                }
        ////            }
        ////            else
        ////            {
                       
        ////                var friend = await db.Users.FirstOrDefaultAsync(p => p.Id == inRecord.ContactID.ToString());
        ////                bool invalidContactId = friend == null;

        ////                if (invalidContactId)
        ////                {
        ////                    responce.Invalid++;
        ////                }
        ////                else
        ////                {
        ////                    var user = db.Users.Find(userId);

        ////                    db.ContactBook.Add(new Friendship
        ////                    {
        ////                        Friend1Id = userId,
        ////                        Friend1 = user,
        ////                        Friend2Id = friend.Id,
        ////                        Friend2 = friend,
        ////                        State = DBRelationshipState.Pending
        ////                   });

        ////                   responce.Created++;
        ////                }
        ////            }
        ////        }
        ////        await db.SaveChangesAsync();

        ////        foreach (var friend in friendsNet)
        ////        {
        ////            responce.ContactBook.Add(friend.ViewModel(userId));
        ////        }

        ////        return Ok(responce);
        ////    }
        ////}


        /////// <summary>
        /////// Will delete a list of contacts provided. Omit a nickname here, as it does nothing
        /////// </summary>
        /////// <param name="models"></param>
        /////// <returns></returns>
        ////[ResponseType(typeof(FriendshipChangeViewModel))]
        ////[Route("ContactBook")]
        ////public async Task<IHttpActionResult> Delete([FromBody]List<RecordBindingModel> models)
        ////{
        ////    if (!ModelState.IsValid)
        ////    {
        ////        return BadRequest(ModelState);
        ////    }
        ////    else if (models.Count > 1000)
        ////    {
        ////        return BadRequest("That many users? Fuck off");
        ////    }
        ////    else if (models.Count < 1)
        ////    {
        ////        return BadRequest("No data");
        ////    }
        ////    else
        ////    {
        ////        var userId = User.Identity.GetUserId();


        ////        var friendsNet = await db.ContactBook.Where(p =>
        ////            (p.Friend1Id == userId && p.State != DBRelationshipState.Blockedu1) ||
        ////            (p.Friend2Id == userId && p.State != DBRelationshipState.Blockedu2)).ToListAsync();

        ////        FriendshipChangeViewModel responce = new FriendshipChangeViewModel();

  
        ////        //iterate for each record recieved
        ////        foreach (var inRecord in models)
        ////        {
        ////            var friendship = friendsNet.FirstOrDefault(p => p.Friend2Id == inRecord.ContactID.ToString() ||
        ////            p.Friend1Id == inRecord.ContactID.ToString());

        ////            if (friendship != null)
        ////            {
        ////                bool success = friendsNet.Remove(friendship);
        ////                responce.Removed++;
        ////            }
        ////            else
        ////            {
        ////                responce.Invalid++;
        ////            }
        ////        }

        ////        await db.SaveChangesAsync();

        ////        foreach (var friendship in friendsNet)
        ////        {
        ////            responce.ContactBook.Add(friendship.ViewModel(userId));
        ////        }

        ////        return Ok(responce);
        ////    }
        //}


        /////<summary>Searches for users based on the array yousubmit. 
        ///// The array is of strings, and can have mixed phone numbers and emails, thiswill be prssesed regardless</summary>
        ///// 
        //[ResponseType(typeof(SearchViewModel))]
        //[HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        //[Route("ContactBook/SearchUsers")]
        //public async Task<IHttpActionResult> SearchUsers(List<string> searchContacts)
        //{
        //    SearchViewModel reply = new SearchViewModel();
        //    List<ApplicationUser> foundUsers = new List<ApplicationUser>();

        //    if (searchContacts == null)
        //        return BadRequest("No Data");

        //    if (searchContacts.Count == 0)
        //        return BadRequest("No Data");
        //    if (searchContacts.Count > 1000)
        //        return BadRequest("You shall not search more than 1000 users at once, because fuck you");


        //    foreach (var searchItem in searchContacts)
        //    {
        //        if (!string.IsNullOrWhiteSpace(searchItem))
        //        {
        //            if (searchItem.Length > 5)
        //            {
        //                long phone;
        //                if (Int64.TryParse(searchItem, out phone))
        //                {
        //                    var user = await db.Users.FirstOrDefaultAsync(p => p.PhoneNumber == phone);
        //                    if (user != null)
        //                    {
        //                        reply.Found++;
        //                        foundUsers.Add(user);
        //                    }
        //                    else
        //                    {
        //                        reply.NotFound++;
        //                    }
        //                }
        //                else if (searchItem.Contains("@"))
        //                {
        //                    var user = await db.Users.FirstOrDefaultAsync(p => p.Email == searchItem);
        //                    if (user != null)
        //                    {
        //                        reply.Found++;
        //                        foundUsers.Add(user);
        //                    }
        //                    else
        //                    {
        //                        reply.NotFound++;
        //                    }
        //                }
        //                else
        //                {
        //                    reply.Invalid++;
        //                }
        //            }
        //            else
        //            {
        //                reply.Invalid++;
        //            }
        //        }
        //        else
        //        {
        //            reply.Invalid++;
        //        }
        //    }

        //    foreach (var user in foundUsers)
        //    {
        //        reply.FoundContacts.Add((PersonViewModel)user);
        //    }

        //    return Ok(reply);
        //}


        ///// <summary> Retrieves full list of friends, but omits the ones where another user blocked this user </summary>
        ///// <param name="db"></param>
        ///// <param name="userId"></param>
        ///// <returns></returns>
        //internal static async Task<List<Friendship>> RetrieveFriends(ApplicationDbContext db, string userId)
        //{
        //    //Pre-load all the 
        //    var friendships = await db.ContactBook.Where(p => (p.Friend1Id == userId && p.State != DBRelationshipState.Blockedu1 )|| 
        //    (p.Friend2Id == userId && p.State != DBRelationshipState.Blockedu2))
        //        .Include(u => u.Friend1).Include(u => u.Friend2).ToListAsync();

        //    return friendships;
        //}

    }


}
